
const Utilisateurs = () => {
  return (
    <div>
      <h1>Utilisateurs</h1>
    </div>
  )
}

export default Utilisateurs
